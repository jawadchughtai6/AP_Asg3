from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('library/', include('library.urls')), #This includes the library\urls file and looks for it whenever user types in ./library/ in the browser
    path('admin/', admin.site.urls), #This is the first file that django looks at WHENEVER a user requests something from our website. It matches the url user writes with these patterns.
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) # **This is how the image will be displayed. Certain other things needed to be changed to display the image such as the settings file and the detail.html file
