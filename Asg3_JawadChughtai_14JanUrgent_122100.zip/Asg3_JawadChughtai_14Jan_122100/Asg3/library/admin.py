from django.contrib import admin
from .models import Author, Publisher, Student, Book

# Registering the models to the admin panel done below:
admin.site.register(Book)
admin.site.register(Publisher)
admin.site.register(Student)
admin.site.register(Author)