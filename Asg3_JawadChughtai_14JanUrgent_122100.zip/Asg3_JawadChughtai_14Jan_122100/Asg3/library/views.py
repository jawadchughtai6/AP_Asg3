from django.http import Http404
from django.shortcuts import render
from .models import Book


def index(request):
    all_books = Book.objects.all() # This stores all the book objects in the variable all_books so that we can send it to the parameter of render
    context = {'all_books': all_books}
    return render(request, 'library/index.html', context)


def detail(request, book_id):
    try:  # Exception handling is done because when a user requests a page such as 127.0.0.1:8000/library/100, 100 is way more than the number of books i have stored. i have only added 9 books. So whenever a user requests a page that appends with more than 9, i am supposed to get an error.
        book = Book.objects.get(pk=book_id)
    except Book.DoesNotExist: #when user requests a page we dont have, give the following error:
        raise Http404("Book does not exist")
    return render(request, 'library/detail.html', {'book': book})
