from django.db import models

#We start making models below:


class Author(models.Model): #Author and publisher are the first two models that we create because they are then used as foreign keys. If i add Book model first, i receive an error because this author model is used as foreign key in Book model.
    author_name = models.CharField(max_length=100)

    def __str__(self):  # It’s important to add __str__() methods to your models, not only for your own convenience when dealing with the interactive prompt, but also because objects’ representations are used throughout Django’s automatically-generated admin.
        return self.author_name  # We can futher print other instances of this model by using  + '-' + self.(whatever the name if instance is)


class Publisher(models.Model):
    publisher_name = models.CharField(max_length=100)

    def __str__(self):  # It’s important to add __str__() methods to your models, not only for your own convenience when dealing with the interactive prompt, but also because objects’ representations are used throughout Django’s automatically-generated admin.
        return self.publisher_name


class Student(models.Model):  # A model for students who will borrow and return books
    name = models.CharField(max_length=100)
    student_ID = models.IntegerField()
    department = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Book(models.Model): #Django creates a unique column and sets it as primary key by default so we don't need to worry about it
    book_title = models.CharField(max_length=200)
    ISBN = models.IntegerField()
    details = models.CharField(max_length=500) #This is the part which is written just below the book title. e.g. Book title = "COMPUTER NETWORKS" - Details = "-->(A top down approach)<--"
    author = models.ForeignKey(Author, on_delete=models.CASCADE) #on_delete=models.CASCADE: This means that when author is deleted, we need to delete the book as well. This is because a book cannot exist if there is no author. Assumption: Death of the author is not considered.
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE) #on_delete=models.CASCADE: This means that when publisher is deleted, we need to delete the book as well. This is because a book cannot exist if there is no publisher. Assumption: Death of the publisher is not considered.
    image = models.ImageField(upload_to='bookimages', blank=True)#This will allow me to show image in the details template to the student

    def __str__(self):
        return self.book_title

#KINDLY NOTE: Please read the comments in all the files. Also, It took me a lot of effort to build this much of the assignment.
# Borrowing and returning of books still needs to be implemented but i
# have a basic knowledge of how to get it done. It would require using POST call whenever student presses the button for issuing book and this will
#enter that book in the students database of borrowed books. Ofcourse CSRF token would be used to secure the session of the student.




