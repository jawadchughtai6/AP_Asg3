from django.urls import path
from . import views


urlpatterns = [
    #/library/
    path('', views.index, name='index'),

    #/library/1123
    path('<int:book_id>/', views.detail, name='detail'), #This is a new url which checks the bookid and opens details of it and lets student issue that book
]
